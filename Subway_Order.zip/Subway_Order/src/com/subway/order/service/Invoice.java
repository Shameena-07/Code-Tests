package com.subway.order.service;


import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.subway.order.model.Subway;


public class Invoice extends Subway {



	public void subInvoice(Boolean ifSub) {



		if(ifSub==true) {

			System.out.println("Your invoice for Sub of the Day");

			Crust c = Crust.HARD;
			FILLING fill = FILLING.CHICKEN_TIKKA;
			TOPPINGS tops = TOPPINGS.MEAT_STRIP;
			TOPPINGS tops1 = TOPPINGS.CUCUMBER;;

			System.out.println("Crust     "+c+"          - "+c.cost+"Rs");
			System.out.println("Filling   "+fill+" - "+fill.cost+"Rs");
			System.out.println("Toppings  "+tops+"    - "+tops.cost+"Rs");
			System.out.println("Toppings  "+tops+"    - "+tops1.cost+"Rs");


			TOPPINGS addtops = TOPPINGS.CABBAGE;
			System.out.println("Toppings  "+addtops+"      - "+" 0Rs");

			int total = c.cost + fill.cost+tops.cost+tops1.cost;

			System.out.println("Total -" +total);

		}


	}

	public void subInvoice(String selcrust, String selFill, List<String> selTop) {


		System.out.println("Your invoice for Sub");

		Crust c = Crust.valueOf(selcrust);
		FILLING fill = FILLING.valueOf(selFill);

		System.out.println("Crust     "+c+"          - "+c.cost+"Rs");
		System.out.println("Filling   "+fill+" - "+fill.cost+"Rs");

		int total = c.cost + fill.cost;

		HashMap<String, Integer> hm = new HashMap<String, Integer>();


		for(String eachTop : selTop ) {

			TOPPINGS tops = TOPPINGS.valueOf(eachTop);
			hm.put(tops.toString(),tops.cost);

		}


		Map<String, Integer> sortedMap = sortByValue(hm);





		int index = 0;

		// print the sorted hashmap

		for (Map.Entry<String, Integer> en : sortedMap.entrySet()) {
			
			index++;

			if (index == sortedMap.size()) {

				System.out.println("Topping  " + en.getKey() +" - " +"0 Rs"); }


			else {


				System.out.println("Topping  " + en.getKey() +" - " + en.getValue() +"Rs");

			} 
			
			total += en.getValue();

		}


		System.out.println("Total -" +total+" Rs");






	}

	public static HashMap<String, Integer> sortByValue(HashMap<String, Integer> hm)
	{
		// Create a list from elements of HashMap
		List<Map.Entry<String, Integer> > list =
				new LinkedList<Map.Entry<String, Integer> >(hm.entrySet());

		// Sort the list
		Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() {
			public int compare(Map.Entry<String, Integer> o1,
					Map.Entry<String, Integer> o2)
			{
				return (o2.getValue()).compareTo(o1.getValue());
			}
		});

		// put data from sorted list to hashmap
		HashMap<String, Integer> temp = new LinkedHashMap<String, Integer>();
		for (Map.Entry<String, Integer> aa : list) {
			temp.put(aa.getKey(), aa.getValue());
		}
		return temp;
	}




}

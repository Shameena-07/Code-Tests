package com.subway.order.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Scanner;

import com.subway.order.model.Subway;

public class MakeSub extends Subway {
	
	Invoice invoice = new Invoice();
	Scanner scanner = new Scanner(System.in); 
	int input;


	public void makeOwnSub() {
		

		System.out.println("--------------------");
		System.out.println("Make Your Own Sub");	
		System.out.println("--------------------");
	
		System.out.println("Select 'Crust' (max of 1):");
		String selcrust = getCrust();
	
		
		System.out.println("Select 'Filling' (max of 1):");
		String selFill = getFilling();
	
		
		System.out.println("Select 'Toppings' (max of 3):");
		List<String> selTop = getToppings();

		invoice.subInvoice(selcrust,selFill,selTop);

		
		
	}
	
	public String getCrust() {
		
		
		for (Crust s : Crust.values()) {

			System.out.println(s.ordinal()+1+")"+s +" - "+ s.cost+" Rs");
			
		}
		input =scanner.nextInt();

		//System.out.println(Crust.values()[input-1].toString());

		


		return Crust.values()[input-1].toString();
	}

	
	
	  public String getFilling() {
	  
	  for (FILLING f : FILLING.values()) {
	  
	  System.out.println(f.ordinal()+1+")"+f +" - "+ f.cost+" Rs"); 
	  
	  }
	  
	  input =scanner.nextInt();
 
	  
	  return FILLING.values()[input-1].toString(); 
	  }
	  
	  
	  public List<String> getToppings() {
		  
		  
		  List<String> selTopList = new ArrayList<String>();
	  
	  for (TOPPINGS t : TOPPINGS.values()) {
	  
	  System.out.println(t.ordinal()+1+")"+t +" - "+ t.cost+" Rs"); 
	  }
	  
	  for(int i=0;i<=2;i++) {
		  
		  input =scanner.nextInt();
		  selTopList.add(TOPPINGS.values()[input-1].toString());
		 
	  }
	  
	
	 
	  
	  return selTopList; 
	  }
	  
	 
}

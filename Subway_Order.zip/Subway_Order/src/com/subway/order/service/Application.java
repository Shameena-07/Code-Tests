package com.subway.order.service;

import java.util.Scanner;

public class Application {
	
	 
	
	
	public static void printWelcomeMessage() {
		
		System.out.println("--------------------");
		System.out.println("Welcome to Subway:");
		System.out.println("--------------------");
		
	}
	
	



	public static void main(String[] args) {
		
		Invoice invoice = new Invoice();
		MakeSub makeSub = new MakeSub();
		
		Scanner scanner = new Scanner(System.in); 
		int input;
		
		printWelcomeMessage();
		
		System.out.println("1)Order 'Sub' off the day");
		System.out.println("2)Order your own 'Sub'");
		System.out.println("3)Exit");
		
		input =scanner.nextInt();
		
		boolean ifSub;

		
		switch (input) {
		case 1:
			
			ifSub = true;
			invoice.subInvoice(ifSub);
			break;
			
		case 2:
			
			
			makeSub.makeOwnSub();
			
			
			break;

		case 3:
			System.out.println("exit");
			break;


		
		}
		
		
	}

}

package com.subway.order.model;



public class Subway {

	public enum Crust{
		HARD(10),THIN(10),SOFT(12);
		
		public int cost;

		Crust(int cost) {
			this.cost = cost;
		}
	}
	
	
	
	public enum FILLING{
		CHICKEN_TIKKA(120),PANNER_TIKKA(100),TURKEY_MEAT(130);
		
		public int cost;

		FILLING(int cost) {
			
			this.cost = cost;
		}
	}
	
	
	
	public enum TOPPINGS{
		CUCUMBER(25),TOMATO(20),MEAT_STRIP(45),CABBAGE(20);
		
		public int cost;

		TOPPINGS(int cost) {
			
			this.cost = cost;
		}
	}
	
	
	
	

}
